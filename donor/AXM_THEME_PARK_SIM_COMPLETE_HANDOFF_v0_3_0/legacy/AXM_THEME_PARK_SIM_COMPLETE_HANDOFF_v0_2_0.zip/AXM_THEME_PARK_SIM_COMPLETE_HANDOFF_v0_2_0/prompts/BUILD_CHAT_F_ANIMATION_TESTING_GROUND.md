# BUILD CHAT — F — Low-Graphic Animation Testing Ground

## Restore

`/returncore /soulcheck /game-agent /theme-park-sim /realistic-determinism /mergegate`

Build **F — Low-Graphic Animation Testing Ground** on top of:

`AXM_THEME_PARK_SIM_COMPLETE_HANDOFF_v0_2_0`

## Intake first

Run `python scripts/verify_package.py`.

Read:

- `FOUNDATION_ROOTS.md`
- `ARCHITECTURE.md`
- `contracts/FOUNDATION_CONTRACT.json`
- `manifests/animation_testing_ground.json`
- relevant docs and examples.

Treat canonical root files as read-only unless returning a separate explicit
change request.

## Branch ownership

- visual assets and provenance;
- simple self-made movement/animation clips;
- ride, queue, crowd, weather, and interaction render adapters;
- visual debug overlays and upgrade ladder.

## Must consume, not silently redefine

Authoritative world, ride, visitor, crew, scenery, weather, and observation
state without changing the simulation.

## Required design behavior

Reach readable self-made low graphics first. Improve in explicit passes.
Keep low-spec modes viable and label concept art honestly.

## Forbidden shortcuts

- age-only demand decay;
- one global popularity bar;
- scenery value from object count;
- automatic forced replacement;
- unseeded state-changing randomness;
- unexplained important outcomes;
- direct mutation of another branch's private state;
- loss of confidence or evidence status;
- beginner behavior different from advanced simulation;
- adventure state separate from management state.

## Required return packet

1. Versioned module manifest.
2. Domain entities and JSON contracts.
3. Declared emitted/consumed events.
4. Deterministic reference implementation or explicit scaffold.
5. Replay tests and forbidden-shortcut tests.
6. Explanation packets and beginner summaries from the same state.
7. Cross-branch integration example.
8. Save/migration effect, if any.
9. Unresolved questions and missing capabilities.
10. Honest Action Report: implemented / simulated / placeholder.
11. Merge-ready ZIP.

## Merge question

How does this branch help players maintain, evolve, or deliberately replace park
elements without artificial demolition chores?
