# Changelog

## v0.2.0 — 2026-08-12

### Preserved

- all v0.1.0 roots;
- original foundation ZIP and unpacked files;
- original complete design backup;
- four branch ownership boundaries;
- deterministic replay principle;
- no age-only demand decay;
- no global popularity bar.

### Added

- world clock, seasons, schedules, weather;
- expanded audience-specific demand inputs;
- attendance/scale evaluator;
- maintain/evolve/replace strategy assessment;
- identity intent and alignment;
- evidence status and uncertainty;
- campaign outcome engine;
- authoritative observation packets;
- tamper-evident event hash chain;
- save/migration/merge systems;
- presentation profiles;
- JSON schemas and example manifests;
- local and next-chat intake prompts;
- first-map target scope;
- visual provenance;
- expanded tests and verifier.

### Changed

- package name now reflects a complete handoff rather than only the first
  deterministic foundation.
- reference weights remain tunable and non-canonical.
- the Python package remains standard-library-only.

### Not added

- no complete game engine;
- no production renderer;
- no full ride, visitor, crew, scenery, shop, or physics implementation;
- no fake claim of playable maps.
