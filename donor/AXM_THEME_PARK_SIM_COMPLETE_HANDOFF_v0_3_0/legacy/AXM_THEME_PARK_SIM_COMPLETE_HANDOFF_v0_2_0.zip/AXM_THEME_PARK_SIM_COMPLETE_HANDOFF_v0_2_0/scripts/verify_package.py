from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import os
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "START_HERE.txt",
    "FOUNDATION_ROOTS.md",
    "ARCHITECTURE.md",
    "BRANCH_MAP.md",
    "ACTION_REPORT.md",
    "contracts/FOUNDATION_CONTRACT.json",
    "contracts/ROOT_HASH_MANIFEST.json",
    "src/park_foundation/__init__.py",
    "prompts/NEXT_CHAT_MASTER_PROMPT.txt",
    "prompts/LOCAL_AGENT_INTAKE_PROMPT.txt",
    "backups/AXM_THEME_PARK_SIM_COMPLETE_DESIGN_BACKUP_2026-08-04.txt",
    "legacy/AXM_THEME_PARK_DETERMINISTIC_FOUNDATION_v0_1_0.zip",
]


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_required() -> list[str]:
    return [item for item in REQUIRED if not (ROOT / item).is_file()]


def verify_roots() -> list[str]:
    manifest = json.loads(
        (ROOT / "contracts" / "ROOT_HASH_MANIFEST.json").read_text(encoding="utf-8")
    )
    issues = []
    actual = {}
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file():
            issues.append(f"missing canonical root: {name}")
            continue
        value = sha256_file(path)
        actual[name] = value
        if value != expected:
            issues.append(f"canonical root hash mismatch: {name}")
    aggregate = sha256(
        json.dumps(actual, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if aggregate != manifest["aggregate_root_hash"]:
        issues.append("aggregate canonical root hash mismatch")
    return issues


def verify_index() -> list[str]:
    index_path = ROOT / "PROJECT_INDEX.json"
    if not index_path.is_file():
        return ["PROJECT_INDEX.json is missing"]
    index = json.loads(index_path.read_text(encoding="utf-8"))
    issues = []
    for item in index["files"]:
        path = ROOT / item["path"]
        if not path.is_file():
            issues.append(f"indexed file missing: {item['path']}")
            continue
        if path.stat().st_size != item["bytes"]:
            issues.append(f"size mismatch: {item['path']}")
        if sha256_file(path) != item["sha256"]:
            issues.append(f"hash mismatch: {item['path']}")
    return issues


def run_tests() -> tuple[int, str]:
    command = [
        sys.executable, "-m", "unittest", "discover",
        "-s", str(ROOT / "tests"), "-p", "test_*.py", "-v",
    ]
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        command, cwd=ROOT, capture_output=True, text=True, env=env
    )
    return completed.returncode, (completed.stdout + completed.stderr).strip()


def main() -> int:
    print("AXM Theme Park Simulator package verifier v0.2.0")
    missing = verify_required()
    root_issues = verify_roots()
    index_issues = verify_index()
    test_code, test_output = run_tests()

    print(f"Required files: {'OK' if not missing else 'FAILED'}")
    for issue in missing:
        print(f"  - {issue}")

    print(f"Canonical roots: {'OK' if not root_issues else 'FAILED'}")
    for issue in root_issues:
        print(f"  - {issue}")

    print(f"Project index: {'OK' if not index_issues else 'FAILED'}")
    for issue in index_issues:
        print(f"  - {issue}")

    print(f"Tests: {'OK' if test_code == 0 else 'FAILED'}")
    print(test_output)

    ok = not missing and not root_issues and not index_issues and test_code == 0
    print(f"FINAL: {'PASS' if ok else 'FAIL'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
