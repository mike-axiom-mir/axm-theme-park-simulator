# AXM Theme Park Simulator — Complete Handoff v0.2.0

This is the strengthened shared foundation for a long-term theme-park simulator,
campaign adventure, and AXM low-graphic animation testing ground.

The project combines:

- readable classic tycoon construction;
- the ability to enter and experience the park;
- realistic causal simulation rather than arbitrary decay;
- multiple viable park identities;
- campaigns about understanding living places;
- a gradual visual-development ladder;
- a future sealed science-fiction reasoning branch.

## Main design statement

> Build, understand, maintain, evolve, and preserve history. Do not force the
> player to demolish useful attractions because an invisible age timer demands
> activity.

## What changed in v0.2.0

v0.1.0 established the roots, contracts, three core evaluators, deterministic
event replay, branch ownership, and six tests.

v0.2.0 keeps those roots and adds:

- world time, seasons, opening schedules, and deterministic weather;
- audience-specific first-time and repeat support in reachable demand;
- active attendance and park-scale evaluation;
- maintain/evolve/replace strategy review without forced action;
- player park-identity intent;
- evidence status, confidence, missing evidence, and observation packets;
- campaigns with multiple valid outcomes;
- one authoritative state for management and adventure views;
- event hash-chain validation;
- save compatibility, explicit migrations, and merge gates;
- beginner/standard/advanced views over the same simulation result;
- schemas, branch manifests, examples, verification scripts, and expanded tests;
- the full design backup, four concept posters, and the original v0.1.0 package.

## Run

No third-party Python package is required.

```bash
python scripts/verify_package.py
python examples/run_reference_demo.py
```

The implementation is a deterministic reference layer. It is not presented as
the finished game engine.
