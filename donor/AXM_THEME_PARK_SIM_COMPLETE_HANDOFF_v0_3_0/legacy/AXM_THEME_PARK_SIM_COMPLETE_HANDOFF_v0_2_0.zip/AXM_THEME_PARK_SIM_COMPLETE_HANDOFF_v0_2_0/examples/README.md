# Examples

Run:

```bash
python examples/run_reference_demo.py
```

The demo intentionally shows:

- one old ride as new to tourists;
- locals depending more on repeat strength;
- indirect and heritage value;
- active attendance and capacity;
- maintain/evolve/replace as review, not a command;
- missing identity evidence reducing confidence;
- deterministic time/weather;
- multiple eligible campaign futures;
- event hash-chain validation.

`EXAMPLE_OUTPUT.txt` is generated during release verification.
