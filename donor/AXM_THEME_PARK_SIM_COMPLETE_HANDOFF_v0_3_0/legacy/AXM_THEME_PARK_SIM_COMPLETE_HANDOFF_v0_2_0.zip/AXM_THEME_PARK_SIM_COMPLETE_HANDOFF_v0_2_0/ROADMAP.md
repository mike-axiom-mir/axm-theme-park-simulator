# Roadmap

## Now — foundation intake

- verify v0.2.0;
- preserve root hashes;
- ingest locally without rebuilding;
- choose one domain branch;
- return a versioned module with tests and honest status.

## Next — primary game organs

Recommended parallel order:

1. Visitors and Crews — establishes living demand, movement, queues, memory.
2. Rides and Attractions — provides experiences, capacity, operation, condition.
3. Decoration and Influence — turns space into atmosphere without decoration spam.
4. Stores and Economy — closes daily operations and financial feedback.

Rides and visitors should agree on shared event/evidence contracts before either
branch becomes too deep.

## Reachable first-map target — November/December 2026

Target a small honest playable slice:

- one small map and clear park entrance;
- path placement or a fixed editable path network;
- a few simple attractions;
- basic visitors, queueing, and active attendance;
- one maintenance or operating loop;
- simple money flow;
- management view plus basic walk/inspection camera;
- self-made low-graphic movement and ride animation;
- deterministic save/replay;
- visible in-production labelling.

Not required for the first maps:

- complete coaster physics;
- huge asset library;
- resort simulation;
- advanced architect tools;
- final campaign set;
- alien DLC;
- photorealistic graphics.

## Later

- campaign inheritance;
- seasonal operations;
- transport and hotels;
- animation upgrade passes;
- richer ride construction;
- physics integration;
- theme-architect planning;
- AI player/observer seats;
- sealed alien postgame reasoning expansion.
