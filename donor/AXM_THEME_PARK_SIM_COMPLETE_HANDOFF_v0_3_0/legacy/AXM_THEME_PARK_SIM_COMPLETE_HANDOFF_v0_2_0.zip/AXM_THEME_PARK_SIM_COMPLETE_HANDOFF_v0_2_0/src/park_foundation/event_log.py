from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import random
from typing import Any, Dict, List

from .canonical import canonical_json, sha256_text


GENESIS_HASH = "0" * 64


@dataclass(frozen=True)
class ParkEvent:
    event_id: str
    event_type: str
    tick: int
    actor_id: str
    target_ids: List[str]
    payload: Dict[str, Any]
    seed: int
    module_id: str
    module_version: str
    evidence_refs: List[str]

    def __post_init__(self) -> None:
        if not self.event_id:
            raise ValueError("event_id is required")
        if self.tick < 0:
            raise ValueError("tick must be non-negative")
        if self.seed < 0:
            raise ValueError("seed must be non-negative")


@dataclass(frozen=True)
class EventRecord:
    event: ParkEvent
    previous_hash: str
    record_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event": asdict(self.event),
            "previous_hash": self.previous_hash,
            "record_hash": self.record_hash,
        }


class DeterministicEventLog:
    def __init__(self) -> None:
        self._records: List[EventRecord] = []

    @staticmethod
    def _record_hash(event: ParkEvent, previous_hash: str) -> str:
        return sha256_text(canonical_json({
            "event": asdict(event),
            "previous_hash": previous_hash,
        }))

    def append(self, event: ParkEvent) -> EventRecord:
        if self._records and event.tick < self._records[-1].event.tick:
            raise ValueError("Events must be appended in non-decreasing tick order.")
        if any(existing.event.event_id == event.event_id for existing in self._records):
            raise ValueError(f"Duplicate event_id: {event.event_id}")
        previous = self._records[-1].record_hash if self._records else GENESIS_HASH
        record = EventRecord(
            event=event,
            previous_hash=previous,
            record_hash=self._record_hash(event, previous),
        )
        self._records.append(record)
        return record

    def seeded_rng(self, event: ParkEvent) -> random.Random:
        return random.Random(event.seed)

    def validate_chain(self) -> bool:
        expected_previous = GENESIS_HASH
        seen_ids = set()
        prior_tick = -1
        for record in self._records:
            event = record.event
            if event.event_id in seen_ids:
                return False
            if event.tick < prior_tick:
                return False
            if record.previous_hash != expected_previous:
                return False
            expected_hash = self._record_hash(event, record.previous_hash)
            if record.record_hash != expected_hash:
                return False
            expected_previous = record.record_hash
            seen_ids.add(event.event_id)
            prior_tick = event.tick
        return True

    def replay_packet(self) -> str:
        return canonical_json([record.to_dict() for record in self._records])

    def event_log_hash(self) -> str:
        return sha256_text(self.replay_packet())

    @property
    def events(self) -> List[ParkEvent]:
        return [record.event for record in self._records]

    @property
    def records(self) -> List[EventRecord]:
        return list(self._records)
