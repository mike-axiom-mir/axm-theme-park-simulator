"""AXM Theme Park deterministic foundation reference package v0.2.0."""

from .version import (
    __version__,
    FOUNDATION_CONTRACT_VERSION,
    SAVE_FORMAT_VERSION,
    CANONICAL_ROOT_HASH,
)
from .canonical import (
    canonical_json,
    sha256_file,
    sha256_text,
    sha256_value,
    stable_seed,
)
from .models import (
    DemandInputs,
    AtmosphereInputs,
    ContributionInputs,
    AttendanceBalanceInputs,
    StrategyInputs,
    ExplanationPacket,
    StrategyAssessment,
)
from .evaluator import (
    evaluate_reachable_demand,
    evaluate_atmosphere,
    evaluate_contribution,
    evaluate_active_attendance_balance,
    evaluate_strategy,
)
from .evidence import EvidenceRef, UncertainValue, evidence_confidence
from .world import (
    WorldClock,
    SeasonCalendar,
    OpeningWindow,
    OpeningSchedule,
    WeatherProfile,
    WeatherState,
    WeatherGenerator,
)
from .event_log import ParkEvent, EventRecord, DeterministicEventLog
from .registry import ModuleManifest, ModuleRegistry, FORBIDDEN_SHORTCUTS
from .identity import ParkIdentityIntent, evaluate_identity_alignment
from .campaign import (
    Condition,
    OutcomePath,
    CampaignDefinition,
    CampaignState,
    CampaignEvaluator,
)
from .observation import ObservationPacket
from .savegame import SaveManifest, MigrationPlan, SaveVerifier
from .merge_gate import ChangeRequest, MergeDecision, MergeGate
from .presentation import (
    PresentationProfile,
    BEGINNER,
    STANDARD,
    ADVANCED,
    render_explanation,
)
from .integrity import IntegrityReport, find_forbidden_shortcuts, validate_integrity

__all__ = [
    "__version__", "FOUNDATION_CONTRACT_VERSION", "SAVE_FORMAT_VERSION",
    "CANONICAL_ROOT_HASH", "canonical_json", "sha256_file", "sha256_text",
    "sha256_value", "stable_seed", "DemandInputs", "AtmosphereInputs",
    "ContributionInputs", "AttendanceBalanceInputs", "StrategyInputs",
    "ExplanationPacket", "StrategyAssessment", "evaluate_reachable_demand",
    "evaluate_atmosphere", "evaluate_contribution",
    "evaluate_active_attendance_balance", "evaluate_strategy", "EvidenceRef",
    "UncertainValue", "evidence_confidence", "WorldClock", "SeasonCalendar",
    "OpeningWindow", "OpeningSchedule", "WeatherProfile", "WeatherState",
    "WeatherGenerator", "ParkEvent", "EventRecord", "DeterministicEventLog",
    "ModuleManifest", "ModuleRegistry", "FORBIDDEN_SHORTCUTS",
    "ParkIdentityIntent", "evaluate_identity_alignment", "Condition",
    "OutcomePath", "CampaignDefinition", "CampaignState", "CampaignEvaluator",
    "ObservationPacket", "SaveManifest", "MigrationPlan", "SaveVerifier",
    "ChangeRequest", "MergeDecision", "MergeGate", "PresentationProfile",
    "BEGINNER", "STANDARD", "ADVANCED", "render_explanation",
    "IntegrityReport", "find_forbidden_shortcuts", "validate_integrity",
]
